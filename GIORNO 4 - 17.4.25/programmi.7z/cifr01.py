def cesare_decifra_tutte_chiavi(messaggio):
    alfabeto = 'ABCDEFGHILMNOPQRSTUVZ'
    messaggio = messaggio.upper()
    
    for chiave in range(1, 21):
        testo_decifrato = ''
        for carattere in messaggio:
            if carattere in alfabeto:
                indice = alfabeto.index(carattere)
                indice_shiftato = (indice - chiave) % 21
                testo_decifrato += alfabeto[indice_shiftato]
            else:
                testo_decifrato += carattere  # lascia spazi e simboli invariati
        print(f'Chiave {chiave:}: {testo_decifrato}')

if __name__ == "__main__": 
    messaggio_cifrato = input("Inserisci il messaggio cifrato: ")
    print("\nPossibili decifrazioni: \n")
    cesare_decifra_tutte_chiavi(messaggio_cifrato)

