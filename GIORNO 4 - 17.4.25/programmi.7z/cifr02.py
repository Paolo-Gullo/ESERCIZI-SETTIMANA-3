''' Prima vado sul terminale di kali e scrivo il seguente comando: echo "QWJhIHZ6b2VidHl2bmdyIHB1ciB6ciBhciBucHBiZXRi" | base64 -d
    Base64 mi permette di convertire i dati codificati nel formato originale. 
    Il risultato del comando lanciato sul terminale di kali è il seguente: Aba vzoebtyvngr pur zr ar nppbetb 
    A questo punto inserisco il risultato che ricercavo nel programma creato su python e arrivo alla soluzione.
'''


def cesare_decifra_tutte_chiavi(messaggio):
    alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    messaggio = messaggio.upper()
    
    for chiave in range(1, 26):
        testo_decifrato = ''
        for carattere in messaggio:
            if carattere in alfabeto:
                indice = alfabeto.index(carattere)
                indice_shiftato = (indice - chiave) % 26
                testo_decifrato += alfabeto[indice_shiftato]
            else:
                testo_decifrato += carattere  
        print(f'Chiave {chiave:}: {testo_decifrato}')

if __name__ == "__main__": 
    messaggio_cifrato = input("Inserisci il messaggio cifrato: ")
    print("\nPossibili decifrazioni: \n")
    cesare_decifra_tutte_chiavi(messaggio_cifrato)